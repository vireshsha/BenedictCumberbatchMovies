//
//  Constants.swift
//  BenedictCumberbatchMovies
//
//  Created by VIRESH KUMAR SHARMA on 2025-11-04.
//

import Foundation

enum Constants {
    static let tmdbAPIKey = "dfa61367da9a3c896b9fd55109f49b0c"
    static let baseURL = "https://api.themoviedb.org/3"
    static let imageBaseURL = "https://image.tmdb.org/t/p/w500"
    static let cumberbatchPersonId = 71580
}
